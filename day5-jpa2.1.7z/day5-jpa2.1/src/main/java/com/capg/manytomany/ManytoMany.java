package com.capg.manytomany;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
	
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction(); 
		
		transaction.begin();
		
		Events corejava=new Events();
		corejava.setEventId("1001-COREJAVA");
		corejava.setEventName("COREJAVA");
		corejava.setEventDate(LocalDate.of(1995, 11, 25));
		
		Events python=new Events();
		python.setEventId("1002-PYTHON");
		python.setEventName("PYTHON");
		python.setEventDate(LocalDate.of(2001, 10, 19));
		
		Events angularjs=new Events();
		angularjs.setEventId("1003-ANGULARJS");
		angularjs.setEventName("ANGULARJS");
		angularjs.setEventDate(LocalDate.of(2005, 11, 10));
		
		Delegates shiva=new Delegates(112,"manoj");
		Delegates neeraj=new Delegates(15,"sai");
		Delegates manoj=new Delegates(115,"bhupal");
		Delegates akhil=new Delegates(123,"vignesh");
		Delegates vamsi=new Delegates(156,"rahul");
		
		entityManager.persist(sai);
		entityManager.persist(manoj);
		entityManager.persist(bhupal);
		entityManager.persist(vignesh);
		entityManager.persist(rahul);
		
		rahul.getEvents().add(corejava);
		rahul.getEvents().add(python);
		manoj.getEvents().add(angularjs);
		bhupal.getEvents().add(corejava);
		vignesh.getEvents().add(python);
		vignesh.getEvents().add(corejava);
		manoj.getEvents().add(python);
		vignesh.getEvents().add(angularjs);
		

		
		
		entityManager.persist(corejava);
		entityManager.persist(angularjs);
		entityManager.persist(python);
		
		
		
		transaction.commit();
		entityManager.close();
	}

}
