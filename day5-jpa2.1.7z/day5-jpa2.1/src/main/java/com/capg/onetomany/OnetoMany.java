package com.capg.onetomany;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TesterClass {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction(); 
		
		transaction.begin();
		Company wipro=new Company("Wipro consultancies");
		Company capg=new Company("Capgemini");
		
		Employee employee=new Employee(101,"manoj",wipro);
		employee.setHiringDate(LocalDate.of(2015, 8, 12));
		Employee employee1=new Employee(102,"vignesh",capg);
		employee1.setHiringDate(LocalDate.of(2017, 10, 15));
		Employee employee2=new Employee(103,"sai",wipro);
		employee2.setHiringDate(LocalDate.of(2001, 6, 20));
		Employee employee3=new Employee(104,"bhupal",capg);
		employee3.setHiringDate(LocalDate.of(2011, 5, 26));
	
		
		entityManager.persist(wipro);
		entityManager.persist(capg);
		entityManager.persist(employee);
		entityManager.persist(employee1);
		entityManager.persist(employee2);
		entityManager.persist(employee3);
		transaction.commit();
		entityManager.close();

	}

}
