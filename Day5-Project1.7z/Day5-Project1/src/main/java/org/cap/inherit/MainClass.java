package org.cap.inherit;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();


transaction.begin();
Project project=new Project("hdfc bank",1001);
Module module=new Module();
module.setProjectId(123);
module.setProjectName("Trans");
module.setModuleName("Login Mod");

Task task=new Task();
task.setProjectId(101);
task.setProjectName("discover");
task.setModuleName("Client Module");

entityManager.persist(project);
entityManager.persist(module);
entityManager.persist(task);
transaction.commit();
entityManager.close();



	}

}
