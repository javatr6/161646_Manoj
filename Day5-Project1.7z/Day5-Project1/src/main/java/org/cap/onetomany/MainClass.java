package org.cap.onetomany;



import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;


public class MainClass {
public static void main(String[] args) {
EntityManagerFactory emfac=Persistence.createEntityManagerFactory("jpademo") ;
	
	EntityManager entitymanager=emfac.createEntityManager();
    EntityTransaction transaction=entitymanager.getTransaction();
    
    transaction.begin();
   Company tcs=new Company("TATA Consultancy Services");
   Company cap=new Company("Capgemini");
Employee employee1=new Employee(1001,"don",tcs);
Employee employee2=new Employee(1002,"adam",cap);

Employee employee3=new Employee(1003,"jones",cap);
Employee employee4=new Employee(1004,"win",tcs);
 
   entitymanager.persist(tcs);
   entitymanager.persist(cap);

	entitymanager.persist(employee1);
    entitymanager.persist(employee2);
 	entitymanager.persist(employee3);
	entitymanager.persist(employee4);
	 transaction.commit();
}
}
