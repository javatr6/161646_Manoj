package org.cap.onetomany;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Company {
@Id
@GeneratedValue
private int compantId;
private String companyName;
@OneToMany(mappedBy="company",targetEntity=Employee.class,cascade=CascadeType.ALL,fetch=FetchType.LAZY)
private List<Employee> employee=new ArrayList<>();
public int getCompantId() {
	return compantId;
}

public void setCompantId(int compantId) {
	this.compantId = compantId;
}
public String getCompanyName() {
	return companyName;
}
public void setCompanyName(String companyName) {
	this.companyName = companyName;
}
public List<Employee> getEmployee() {
	return employee;
}
public void setEmployee(List<Employee> employee) {
	this.employee = employee;
}
public Company(int compantId, String companyName, List<Employee> employee) {
	super();
	this.compantId = compantId;
	this.companyName = companyName;
	this.employee = employee;
}
public Company() {
	super();
}

public Company(String companyName) {
	super();
	this.companyName = companyName;
}

@Override
public String toString() {
	return "Company [compantId=" + compantId + ", companyName=" + companyName + ", employee=" + employee + "]";
}

}
