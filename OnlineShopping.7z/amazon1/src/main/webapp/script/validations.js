function validate() {

	flag=false;
	var userName=f1.userName.value;
	var userPass=f1.passWord.value;
	if(userName=="" || userName==null) {
		document.getElementById('error').innerHTML="*please enter username";
		flag=false;
	}else if(userPass=="" || userPass==null) {
		document.getElementById('errpwd').innerHTML="*please enter password";
		flag=false;
	}else {
		flag=true;
	}
	return flag;
}