package org.service;

import org.cap.model.LoginBean;
import org.dao.ILoginDao;
import org.dao.LoginDaoImpl;


public class LoginServiceImpl implements  ILoginService  {

	ILoginDao loginDao=new LoginDaoImpl();
	@Override
	public boolean isValidLogin(LoginBean loginBean) {
		if(loginDao.isValidLogin(loginBean)) {
			return true;
		}
		return false;
	}
	
}
