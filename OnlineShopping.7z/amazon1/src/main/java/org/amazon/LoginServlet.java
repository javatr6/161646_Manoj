package org.amazon;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.model.LoginBean;
import org.service.ILoginService;
import org.service.LoginServiceImpl;


@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String username=request.getParameter("userName");
		String password=request.getParameter("passWord");
		LoginBean loginBean=new LoginBean(username,password);
		
		ILoginService iLoginService = new LoginServiceImpl();

        PrintWriter pw=response.getWriter();
					
		if(iLoginService.isValidLogin(loginBean)) {
			response.sendRedirect("pages/sucess.html");
		}else {
			String message="please enter valid details";
			request.getRequestDispatcher("/index.html").include(request, response);
			pw.println(message);
		}
		
	
	}
}


