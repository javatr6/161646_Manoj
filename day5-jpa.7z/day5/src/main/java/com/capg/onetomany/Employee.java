package com.capg.onetomany;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Employee {

	@Id
	private int employeeId;
	private String employeeName;
	private LocalDate dateOfJoining;
	@ManyToOne
	@JoinColumn(name="CompanyFk")
	private Company company;







	public Employee(int employeeId, String employeeName, LocalDate dateOfJoining, Company company) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.dateOfJoining = dateOfJoining;
		this.company = company;
	}







	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public LocalDate getDateOfJoining() {
		return dateOfJoining;
	}







	public void setDateOfJoining(LocalDate dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}







	public Company getCompany() {
		return company;
	}







	public void setCompany(Company company) {
		this.company = company;
	}


}
