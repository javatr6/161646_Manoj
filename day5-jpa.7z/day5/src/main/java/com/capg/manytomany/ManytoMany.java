package com.capg.manytomany;



import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class ManytoMany {

	public static void main(String[] args) {
	
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction(); 
		
		transaction.begin();
		
		Events corejava=new Events();
		corejava.setEventId("101-corejava");
		corejava.setEventName("corejava");
		corejava.setEventDate(LocalDate.of(2005, 8, 15));
		
		Events dotnet=new Events();
		dotnet.setEventId("102-dotnet");
		dotnet.setEventName("dotnet");
		dotnet.setEventDate(LocalDate.of(2004, 8, 19));
		
		Events oracle=new Events();
		oracle.setEventId("103-oracle");
		oracle.setEventName("oracle");
		oracle.setEventDate(LocalDate.of(2008, 8, 22));
		
		Delegates manoj=new Delegates(112,"manoj");
		Delegates bhupal=new Delegates(15,"bhupal");
		Delegates sai=new Delegates(115,"sai");
		Delegates vignesh=new Delegates(123,"vignesh");
		Delegates rahul=new Delegates(156,"rahul");
		
		
		entityManager.persist(manoj);
		entityManager.persist(bhupal);
		entityManager.persist(sai);
		entityManager.persist(vignesh);
		entityManager.persist(rahul);
		
		
		manoj.getEvents().add(corejava);
		manoj.getEvents().add(dotnet);
		sai.getEvents().add(oracle);
		bhupal.getEvents().add(corejava);
		manoj.getEvents().add(dotnet);
		vignesh.getEvents().add(corejava);
		sai.getEvents().add(dotnet);
		bhupal.getEvents().add(oracle);
		

		
		
		entityManager.persist(corejava);
		entityManager.persist(oracle);
		entityManager.persist(dotnet);
		
		
		
		transaction.commit();
		entityManager.close();
	}

}
